#!/bin/sh
#Start SchemaSpyGUI
echo 'starting SchemaSpyGUI'
java -jar schemaSpyGUI.jar
